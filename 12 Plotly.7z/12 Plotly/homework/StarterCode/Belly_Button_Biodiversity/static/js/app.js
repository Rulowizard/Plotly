function buildMetadata(sample) {
        
    //A este debe de apuntar el Sample Metadata Table
    //<div id="sample-metadata" class="panel-body"></div>
    //Agarro la referencia al div donde se encuentra el panel
    var panel = d3.select("#sample-metadata");
    //Limpiar la información anterior
    panel.html("");

    // Obtengo el referencia a la dropdown list
    var selector = d3.select("#selDataset");
    //Obtengo el valor de la muestra seleccionada
    var sample = selector.property("value");
    
    //JSON para extraer la información de la metadata
    d3.json(`/metadata/${sample}`).then(function(data){
        //Generar tbody
        var tbody = panel.append("tbody");
        //Generar título
        Object.entries(data).forEach(function([key,value]){
            var row = tbody.append("tr");
            var cell = tbody.append("td"); 
            cell.text(`${key}: ${value}`);
        }); 
    });
    


    // BONUS: Build the Gauge Chart
    // buildGauge(data.WFREQ);
}

function buildCharts(sample) {

  // @TODO: Use `d3.json` to fetch the sample data for the plots

    // @TODO: Build a Bubble Chart using the sample data

    // @TODO: Build a Pie Chart
    // HINT: You will need to use slice() to grab the top 10 sample_values,
    // otu_ids, and labels (10 each).
    
    //<div id="pie"></div>
    var selector = d3.select("#selDataset");
    var sample = selector.property("value");
    
    d3.json(`/samples/${sample}`).then(function(data){
        console.log(data);
        text= [data.otu_labels] ;
        
        var data =[{
           values : data.sample_values,
            labels: data.otu_ids,
            hoverinfo: "text",
            type: "pie"
        }];
        
        Plotly.newPlot("pie",data);
    });
    
    
    d3.json(`/bubbles/${sample}`).then(function(data2){
        console.log(data2);
        
        var dat=[{
            x:data2.otu_ids,
            y:data2.sample_values,
            mode:"markers",
            marker:{
                size: data2.sample_values,
                color: data2.otu_ids,
            } 
        }];
        
        Plotly.newPlot("bubble",dat);
        
    });
    
    
}

function init() {
  // Grab a reference to the dropdown select element
  var selector = d3.select("#selDataset");

  // Use the list of sample names to populate the select options
  d3.json("/names").then((sampleNames) => {
    sampleNames.forEach((sample) => {
      selector
        .append("option")
        .text(sample)
        .property("value", sample);
    });

    // Use the first sample from the list to build the initial plots
    const firstSample = sampleNames[0];
    buildCharts(firstSample);
    buildMetadata(firstSample);
  });
}

function optionChanged(newSample) {
  // Fetch new data each time a new sample is selected
  buildCharts(newSample);
  buildMetadata(newSample);
}

// Initialize the dashboard
init();
